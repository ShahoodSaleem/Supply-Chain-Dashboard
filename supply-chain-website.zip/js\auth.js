// Authentication system for Supply Chain Management
class AuthSystem {
    constructor() {
        this.users = {
            'admin': 'supply123',
            'manager': 'chain456',
            'supervisor': 'logistics789',
            'analyst': 'forecast123'
        };
        this.currentUser = null;
        this.init();
    }

    init() {
        // Check if user is already logged in
        this.checkSession();
        
        // Setup login form listener
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }
    }

    checkSession() {
        const sessionUser = sessionStorage.getItem('currentUser');
        if (sessionUser && window.location.pathname.includes('index.html')) {
            // User is already logged in, redirect to dashboard
            window.location.href = 'dashboard.html';
        } else if (!sessionUser && window.location.pathname.includes('dashboard.html')) {
            // User is not logged in but trying to access dashboard
            window.location.href = 'index.html';
        }
    }

    handleLogin(e) {
        e.preventDefault();
        
        const userId = document.getElementById('userId').value.trim();
        const password = document.getElementById('password').value.trim();
        const errorMessage = document.getElementById('errorMessage');

        // Clear previous error message
        errorMessage.style.display = 'none';
        errorMessage.textContent = '';

        // Validate credentials
        if (this.validateCredentials(userId, password)) {
            // Store user session
            sessionStorage.setItem('currentUser', userId);
            sessionStorage.setItem('loginTime', new Date().toISOString());
            
            // Show success feedback
            this.showSuccess();
            
            // Redirect to dashboard after short delay
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 1500);
        } else {
            // Show error message
            this.showError('Invalid User ID or Password. Please try again.');
        }
    }

    validateCredentials(userId, password) {
        return this.users[userId] && this.users[userId] === password;
    }

    showError(message) {
        const errorMessage = document.getElementById('errorMessage');
        errorMessage.textContent = message;
        errorMessage.style.display = 'block';
        errorMessage.className = 'error-message show';
        
        // Shake animation for login form
        const loginForm = document.querySelector('.login-form');
        loginForm.style.animation = 'shake 0.5s ease-in-out';
        setTimeout(() => {
            loginForm.style.animation = '';
        }, 500);
    }

    showSuccess() {
        const errorMessage = document.getElementById('errorMessage');
        errorMessage.textContent = '✓ Login successful! Redirecting to dashboard...';
        errorMessage.className = 'success-message show';
        errorMessage.style.display = 'block';
    }

    logout() {
        // Clear session storage
        sessionStorage.removeItem('currentUser');
        sessionStorage.removeItem('loginTime');
        
        // Redirect to login page
        window.location.href = 'index.html';
    }

    getCurrentUser() {
        return sessionStorage.getItem('currentUser');
    }

    isAuthenticated() {
        return !!sessionStorage.getItem('currentUser');
    }
}

// Initialize authentication system when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.authSystem = new AuthSystem();
});

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-5px); }
        75% { transform: translateX(5px); }
    }
    
    .error-message.show {
        animation: slideIn 0.3s ease-out;
    }
    
    .success-message.show {
        animation: slideIn 0.3s ease-out;
    }
    
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
`;
document.head.appendChild(style);
