// Advanced Access Control System for Supply Chain Dashboard
class AccessControl {
    constructor() {
        this.init();
    }

    init() {
        // Hide the website initially
        this.hideContent();
        
        // Check for access token in URL
        this.checkAccessToken();
        
        // Check IP whitelist (optional)
        this.checkIPAccess();
        
        // Initialize session monitoring
        this.initSessionMonitoring();
    }

    hideContent() {
        // Add CSS to hide content until authorized (less aggressive)
        const style = document.createElement('style');
        style.textContent = `
            .login-container, .dashboard-container { 
                display: none;
            }
            .access-denied {
                display: flex !important;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
                background: #0f172a;
                color: #e5e7eb;
                font-family: Inter, sans-serif;
                flex-direction: column;
                text-align: center;
            }
            .access-denied h1 {
                color: #ef4444;
                margin-bottom: 1rem;
            }
            .access-denied p {
                color: #9ca3af;
                max-width: 400px;
                line-height: 1.5;
            }
        `;
        document.head.appendChild(style);
    }

    showContent() {
        // Show the main content containers
        const loginContainer = document.querySelector('.login-container');
        const dashboardContainer = document.querySelector('.dashboard-container');
        
        if (loginContainer) {
            loginContainer.style.display = 'block';
        }
        if (dashboardContainer) {
            dashboardContainer.style.display = 'block';
        }
        
        document.body.style.display = 'block';
    }

    checkAccessToken() {
        const urlParams = new URLSearchParams(window.location.search);
        const token = urlParams.get('access') || sessionStorage.getItem('accessToken');
        
        // List of valid access tokens (you can change these)
        const validTokens = [
            'sc2024admin',      // For administrators
            'sc2024manager',    // For managers  
            'sc2024viewer',     // For read-only access
            'sc2024demo'        // For demo purposes
        ];

        if (token && validTokens.includes(token)) {
            sessionStorage.setItem('accessToken', token);
            this.showContent();
            return true;
        } else {
            this.showAccessDenied();
            return false;
        }
    }

    checkIPAccess() {
        // Optional: Implement IP whitelist
        // This would require a backend service to get real IP
        // For now, we'll skip this check
        return true;
    }

    showAccessDenied() {
        document.body.innerHTML = `
            <div class="access-denied">
                <i class="fas fa-shield-alt" style="font-size: 64px; color: #ef4444; margin-bottom: 1rem;"></i>
                <h1>Access Denied</h1>
                <p>This dashboard is restricted to authorized personnel only. Please contact your administrator for access.</p>
                <div style="margin-top: 2rem; padding: 1rem; background: rgba(239, 68, 68, 0.1); border-radius: 8px; border: 1px solid rgba(239, 68, 68, 0.2);">
                    <p style="color: #fecaca; font-size: 0.875rem; margin: 0;">
                        If you believe you should have access, please ensure you're using the correct access link provided by your administrator.
                    </p>
                </div>
            </div>
        `;
        document.body.style.display = 'flex';
    }

    initSessionMonitoring() {
        // Monitor for session changes
        setInterval(() => {
            const token = sessionStorage.getItem('accessToken');
            if (!token) {
                this.showAccessDenied();
            }
        }, 30000); // Check every 30 seconds
    }

    // Method to generate access links (for administrators)
    generateAccessLink(token) {
        const baseUrl = window.location.origin + window.location.pathname;
        return `${baseUrl}?access=${token}`;
    }

    // Method to revoke access
    revokeAccess() {
        sessionStorage.removeItem('accessToken');
        sessionStorage.removeItem('currentUser');
        sessionStorage.removeItem('sessionData');
        this.showAccessDenied();
    }
}

// Initialize access control before anything else
document.addEventListener('DOMContentLoaded', () => {
    window.accessControl = new AccessControl();
});

// Prevent right-click and developer tools (basic protection)
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', e => {
    // Disable F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U
    if (e.keyCode === 123 || 
        (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) ||
        (e.ctrlKey && e.keyCode === 85)) {
        e.preventDefault();
        return false;
    }
});
