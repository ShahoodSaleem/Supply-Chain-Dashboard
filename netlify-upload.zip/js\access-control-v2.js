// Improved Access Control System - Non-Breaking Version
class SimpleAccessControl {
    constructor() {
        this.validTokens = [
            'sc2024admin',      // For administrators
            'sc2024manager',    // For managers  
            'sc2024viewer',     // For read-only access
            'sc2024demo'        // For demo purposes
        ];
        
        this.init();
    }

    init() {
        // Wait for page to load completely
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.checkAccess());
        } else {
            this.checkAccess();
        }
    }

    checkAccess() {
        // Get access token from URL or session
        const urlParams = new URLSearchParams(window.location.search);
        const token = urlParams.get('access') || sessionStorage.getItem('accessToken');
        
        // If no token or invalid token, show access denied
        if (!token || !this.validTokens.includes(token)) {
            this.showAccessDenied();
            return false;
        }

        // Valid token - store it and allow access
        sessionStorage.setItem('accessToken', token);
        this.allowAccess();
        return true;
    }

    showAccessDenied() {
        // Hide main content
        const mainContent = document.querySelector('.login-container, .dashboard-container, .admin-container');
        if (mainContent) {
            mainContent.style.display = 'none';
        }

        // Create and show access denied message
        const accessDeniedDiv = document.createElement('div');
        accessDeniedDiv.className = 'access-denied-overlay';
        accessDeniedDiv.innerHTML = `
            <div class="access-denied-content">
                <i class="fas fa-shield-alt" style="font-size: 64px; color: #ef4444; margin-bottom: 1rem;"></i>
                <h1 style="color: #ef4444; margin-bottom: 1rem;">Access Denied</h1>
                <p style="color: #9ca3af; max-width: 400px; line-height: 1.5; text-align: center;">
                    This dashboard is restricted to authorized personnel only. 
                    Please contact your administrator for access.
                </p>
                <div style="margin-top: 2rem; padding: 1rem; background: rgba(239, 68, 68, 0.1); 
                           border-radius: 8px; border: 1px solid rgba(239, 68, 68, 0.2); max-width: 500px;">
                    <p style="color: #fecaca; font-size: 0.875rem; margin: 0; text-align: center;">
                        If you believe you should have access, please ensure you're using the 
                        correct access link provided by your administrator.
                    </p>
                </div>
            </div>
        `;

        // Style the overlay
        accessDeniedDiv.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: #0f172a;
            color: #e5e7eb;
            font-family: Inter, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        `;

        accessDeniedDiv.querySelector('.access-denied-content').style.cssText = `
            text-align: center;
            max-width: 600px;
            padding: 2rem;
        `;

        document.body.appendChild(accessDeniedDiv);
    }

    allowAccess() {
        // Remove any access denied overlays
        const overlay = document.querySelector('.access-denied-overlay');
        if (overlay) {
            overlay.remove();
        }

        // Ensure main content is visible
        const mainContent = document.querySelector('.login-container, .dashboard-container, .admin-container');
        if (mainContent) {
            mainContent.style.display = 'block';
        }

        // Start session monitoring
        this.startSessionMonitoring();
    }

    startSessionMonitoring() {
        // Check session every 30 seconds
        setInterval(() => {
            const token = sessionStorage.getItem('accessToken');
            if (!token || !this.validTokens.includes(token)) {
                this.showAccessDenied();
            }
        }, 30000);
    }

    // Method to generate access links (for admin panel)
    generateAccessLink(token) {
        const baseUrl = window.location.origin + window.location.pathname;
        return `${baseUrl}?access=${token}`;
    }

    // Method to revoke access
    revokeAccess() {
        sessionStorage.removeItem('accessToken');
        sessionStorage.removeItem('currentUser');
        sessionStorage.removeItem('sessionData');
        this.showAccessDenied();
    }
}

// Initialize access control
window.simpleAccessControl = new SimpleAccessControl();
