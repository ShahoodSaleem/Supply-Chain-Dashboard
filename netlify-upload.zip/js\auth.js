// Authentication system for Supply Chain Management
class AuthSystem {
    constructor() {
        // Encoded user credentials (Base64 encoded for basic obfuscation)
        this.users = {
            'admin': this.encode('supply123'),
            'manager': this.encode('chain456'),
            'supervisor': this.encode('logistics789'),
            'analyst': this.encode('forecast123')
        };
        
        // Session settings
        this.sessionTimeout = 2 * 60 * 60 * 1000; // 2 hours
        this.maxLoginAttempts = 3;
        this.lockoutTime = 15 * 60 * 1000; // 15 minutes
        
        this.currentUser = null;
        this.init();
    }

    encode(password) {
        return btoa(password); // Basic encoding
    }

    decode(encoded) {
        return atob(encoded);
    }

    init() {
        // Check if user is already logged in
        this.checkSession();
        
        // Setup login form listener
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }
    }

    checkSession() {
        const sessionUser = sessionStorage.getItem('currentUser');
        if (sessionUser && window.location.pathname.includes('index.html')) {
            // User is already logged in, redirect to dashboard
            window.location.href = 'dashboard.html';
        } else if (!sessionUser && window.location.pathname.includes('dashboard.html')) {
            // User is not logged in but trying to access dashboard
            window.location.href = 'index.html';
        }
    }

    handleLogin(e) {
        e.preventDefault();
        
        const userId = document.getElementById('userId').value.trim();
        const password = document.getElementById('password').value.trim();
        const errorMessage = document.getElementById('errorMessage');

        // Clear previous error message
        errorMessage.style.display = 'none';
        errorMessage.textContent = '';

        // Validate credentials
        try {
            if (this.validateCredentials(userId, password)) {
                // Store user session with expiration
                const sessionData = {
                    user: userId,
                    loginTime: new Date().toISOString(),
                    expiresAt: new Date(Date.now() + this.sessionTimeout).toISOString()
                };
                
                sessionStorage.setItem('currentUser', userId);
                sessionStorage.setItem('sessionData', JSON.stringify(sessionData));
                
                // Show success feedback
                this.showSuccess();
                
                // Redirect to dashboard after short delay
                setTimeout(() => {
                    window.location.href = 'dashboard.html';
                }, 1500);
            } else {
                // Show error message
                this.showError('Invalid User ID or Password. Please try again.');
            }
        } catch (error) {
            this.showError(error.message);
        }
    }

    validateCredentials(userId, password) {
        // Check if user is locked out
        if (this.isUserLockedOut(userId)) {
            throw new Error('Account temporarily locked due to multiple failed attempts. Please try again later.');
        }

        const isValid = this.users[userId] && this.decode(this.users[userId]) === password;
        
        if (!isValid) {
            this.recordFailedAttempt(userId);
        } else {
            this.clearFailedAttempts(userId);
        }
        
        return isValid;
    }

    isUserLockedOut(userId) {
        const attempts = JSON.parse(localStorage.getItem(`failed_attempts_${userId}`) || '[]');
        const recentAttempts = attempts.filter(time => Date.now() - time < this.lockoutTime);
        return recentAttempts.length >= this.maxLoginAttempts;
    }

    recordFailedAttempt(userId) {
        const attempts = JSON.parse(localStorage.getItem(`failed_attempts_${userId}`) || '[]');
        attempts.push(Date.now());
        localStorage.setItem(`failed_attempts_${userId}`, JSON.stringify(attempts));
    }

    clearFailedAttempts(userId) {
        localStorage.removeItem(`failed_attempts_${userId}`);
    }

    showError(message) {
        const errorMessage = document.getElementById('errorMessage');
        errorMessage.textContent = message;
        errorMessage.style.display = 'block';
        errorMessage.className = 'error-message show';
        
        // Shake animation for login form
        const loginForm = document.querySelector('.login-form');
        loginForm.style.animation = 'shake 0.5s ease-in-out';
        setTimeout(() => {
            loginForm.style.animation = '';
        }, 500);
    }

    showSuccess() {
        const errorMessage = document.getElementById('errorMessage');
        errorMessage.textContent = '✓ Login successful! Redirecting to dashboard...';
        errorMessage.className = 'success-message show';
        errorMessage.style.display = 'block';
    }

    logout() {
        // Clear session storage
        sessionStorage.removeItem('currentUser');
        sessionStorage.removeItem('loginTime');
        
        // Redirect to login page
        window.location.href = 'index.html';
    }

    getCurrentUser() {
        return sessionStorage.getItem('currentUser');
    }

    isAuthenticated() {
        return !!sessionStorage.getItem('currentUser');
    }
}

// Initialize authentication system when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.authSystem = new AuthSystem();
});

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-5px); }
        75% { transform: translateX(5px); }
    }
    
    .error-message.show {
        animation: slideIn 0.3s ease-out;
    }
    
    .success-message.show {
        animation: slideIn 0.3s ease-out;
    }
    
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
`;
document.head.appendChild(style);
