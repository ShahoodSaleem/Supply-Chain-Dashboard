// Dashboard functionality and charts
class SupplyChainDashboard {
    constructor() {
        this.charts = {};
        this.currentUser = null;
        this.init();
    }

    init() {
        // Check authentication
        this.checkAuth();
        
        // Initialize navigation
        this.initNavigation();
        
        // Initialize logout button
        this.initLogout();
        
        // Initialize charts
        this.initCharts();
        
        // Initialize warehouse system
        this.initWarehouseSystem();
        
        // Set welcome message
        this.setWelcomeMessage();
        
        // Auto-refresh data every 30 seconds
        setInterval(() => this.refreshData(), 30000);
    }

    checkAuth() {
        this.currentUser = sessionStorage.getItem('currentUser');
        if (!this.currentUser) {
            window.location.href = 'index.html';
            return;
        }
    }

    initNavigation() {
        const navLinks = document.querySelectorAll('.nav-link');
        const sections = document.querySelectorAll('.section');

        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                
                // Remove active class from all links and sections
                navLinks.forEach(l => l.classList.remove('active'));
                sections.forEach(s => s.classList.remove('active'));
                
                // Add active class to clicked link
                link.classList.add('active');
                
                // Show corresponding section
                const sectionId = link.getAttribute('href').substring(1);
                const targetSection = document.getElementById(sectionId);
                if (targetSection) {
                    targetSection.classList.add('active');
                }
                
                // Refresh charts if needed
                this.refreshSectionCharts(sectionId);
            });
        });
    }

    initLogout() {
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => {
                if (window.authSystem) {
                    window.authSystem.logout();
                } else {
                    sessionStorage.clear();
                    window.location.href = 'index.html';
                }
            });
        }
    }

    setWelcomeMessage() {
        const welcomeMessage = document.getElementById('welcomeMessage');
        if (welcomeMessage && this.currentUser) {
            const userName = this.currentUser.charAt(0).toUpperCase() + this.currentUser.slice(1);
            welcomeMessage.textContent = `Welcome, ${userName}`;
        }
    }

    initCharts() {
        // Initialize all charts
        this.initForecastChart();
        this.initSupplyDemandChart();
        this.initRegionalChart();
        this.initLeadTimeChart();
        this.initInventoryChart();
    }

    initForecastChart() {
        const ctx = document.getElementById('forecastChart');
        if (!ctx) return;

        this.charts.forecast = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Predicted Supply',
                    data: [1200, 1350, 1100, 1400, 1600, 1450, 1700, 1550, 1800, 1650, 1900, 2000],
                    borderColor: '#8b5cf6',
                    backgroundColor: 'rgba(139, 92, 246, 0.15)',
                    fill: true,
                    tension: 0.4,
                    borderWidth: 3,
                    pointBackgroundColor: '#8b5cf6',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2
                }, {
                    label: 'Actual Supply',
                    data: [1150, 1300, 1050, 1380, 1580, 1420, null, null, null, null, null, null],
                    borderColor: '#f59e0b',
                    backgroundColor: 'rgba(245, 158, 11, 0.15)',
                    fill: false,
                    tension: 0.4,
                    borderWidth: 3,
                    pointBackgroundColor: '#f59e0b',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        labels: { color: '#e5e7eb' }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: '#9ca3af' },
                        grid: { color: 'rgba(255,255,255,0.1)' }
                    },
                    y: {
                        ticks: { color: '#9ca3af' },
                        grid: { color: 'rgba(255,255,255,0.1)' }
                    }
                }
            }
        });
    }

    initSupplyDemandChart() {
        const ctx = document.getElementById('supplyDemandChart');
        if (!ctx) return;

        this.charts.supplyDemand = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Q1 2024', 'Q2 2024', 'Q3 2024', 'Q4 2024'],
                datasets: [{
                    label: 'Supply',
                    data: [4500, 5200, 4800, 5500],
                    backgroundColor: 'linear-gradient(135deg, #10b981, #34d399)',
                    borderColor: '#059669',
                    borderWidth: 2,
                    borderRadius: 8,
                    borderSkipped: false
                }, {
                    label: 'Demand',
                    data: [4200, 4900, 5100, 5300],
                    backgroundColor: 'linear-gradient(135deg, #ef4444, #f87171)',
                    borderColor: '#dc2626',
                    borderWidth: 2,
                    borderRadius: 8,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        labels: { color: '#e5e7eb' }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: '#9ca3af' },
                        grid: { color: 'rgba(255,255,255,0.1)' }
                    },
                    y: {
                        ticks: { color: '#9ca3af' },
                        grid: { color: 'rgba(255,255,255,0.1)' }
                    }
                }
            }
        });
    }

    initRegionalChart() {
        const ctx = document.getElementById('regionalChart');
        if (!ctx) return;

        this.charts.regional = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['North America', 'Europe', 'Asia Pacific', 'South America', 'Africa'],
                datasets: [{
                    data: [35, 25, 28, 8, 4],
                    backgroundColor: [
                        '#3b82f6',  // Blue
                        '#8b5cf6',  // Purple
                        '#10b981',  // Emerald
                        '#f59e0b',  // Amber
                        '#ef4444'   // Red
                    ],
                    borderColor: ['#1d4ed8', '#7c3aed', '#059669', '#d97706', '#dc2626'],
                    borderWidth: 3,
                    hoverOffset: 8
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { color: '#e5e7eb' }
                    }
                }
            }
        });
    }

    initLeadTimeChart() {
        const ctx = document.getElementById('leadTimeChart');
        if (!ctx) return;

        this.charts.leadTime = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6'],
                datasets: [{
                    label: 'Raw Materials',
                    data: [14, 13, 15, 12, 11, 12],
                    borderColor: '#ec4899',
                    backgroundColor: 'rgba(236, 72, 153, 0.1)',
                    tension: 0.4,
                    borderWidth: 3,
                    pointBackgroundColor: '#ec4899',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 6
                }, {
                    label: 'Electronics',
                    data: [9, 8, 7, 8, 9, 8],
                    borderColor: '#06b6d4',
                    backgroundColor: 'rgba(6, 182, 212, 0.1)',
                    tension: 0.4,
                    borderWidth: 3,
                    pointBackgroundColor: '#06b6d4',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 6
                }, {
                    label: 'Textiles',
                    data: [7, 6, 5, 6, 7, 6],
                    borderColor: '#84cc16',
                    backgroundColor: 'rgba(132, 204, 22, 0.1)',
                    tension: 0.4,
                    borderWidth: 3,
                    pointBackgroundColor: '#84cc16',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 6
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        labels: { color: '#e5e7eb' }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: '#9ca3af' },
                        grid: { color: 'rgba(255,255,255,0.1)' }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: { color: '#9ca3af' },
                        grid: { color: 'rgba(255,255,255,0.1)' }
                    }
                }
            }
        });
    }

    initInventoryChart() {
        const ctx = document.getElementById('inventoryChart');
        if (!ctx) return;

        this.charts.inventory = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: ['Raw Materials', 'Electronics', 'Textiles', 'Automotive', 'Pharmaceuticals', 'Food & Beverage'],
                datasets: [{
                    label: 'Current Stock',
                    data: [75, 60, 80, 45, 90, 70],
                    borderColor: '#f97316',
                    backgroundColor: 'rgba(249, 115, 22, 0.2)',
                    pointBackgroundColor: '#f97316',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    borderWidth: 3
                }, {
                    label: 'Optimal Level',
                    data: [80, 75, 85, 70, 95, 80],
                    borderColor: '#6366f1',
                    backgroundColor: 'rgba(99, 102, 241, 0.15)',
                    pointBackgroundColor: '#6366f1',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    borderWidth: 3
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        labels: { color: '#e5e7eb' }
                    }
                },
                scales: {
                    r: {
                        beginAtZero: true,
                        ticks: { 
                            color: '#9ca3af',
                            backdropColor: 'transparent'
                        },
                        grid: { color: 'rgba(255,255,255,0.1)' },
                        pointLabels: { color: '#9ca3af' }
                    }
                }
            }
        });
    }

    refreshSectionCharts(sectionId) {
        // Refresh charts when switching sections to ensure proper rendering
        setTimeout(() => {
            switch(sectionId) {
                case 'forecast':
                    if (this.charts.forecast) this.charts.forecast.resize();
                    break;
                case 'charts':
                    if (this.charts.supplyDemand) this.charts.supplyDemand.resize();
                    if (this.charts.regional) this.charts.regional.resize();
                    break;
                case 'leadtimes':
                    if (this.charts.leadTime) this.charts.leadTime.resize();
                    break;
                case 'inventory':
                    if (this.charts.inventory) this.charts.inventory.resize();
                    break;
            }
        }, 100);
    }

    refreshData() {
        // Simulate real-time data updates
        this.updateMetrics();
        this.updateChartData();
        this.updateWarehouseStats();
    }

    updateMetrics() {
        // Update metric cards with simulated real-time data
        const metrics = {
            inventory: { value: 12450 + Math.floor(Math.random() * 100), change: (Math.random() * 10 - 5).toFixed(1) },
            shipments: { value: 248 + Math.floor(Math.random() * 20), change: (Math.random() * 6 - 3).toFixed(1) },
            leadTime: { value: (14.2 + Math.random() * 2 - 1).toFixed(1), change: (Math.random() * 3 - 1.5).toFixed(1) },
            alerts: { value: 7 + Math.floor(Math.random() * 5), change: Math.floor(Math.random() * 5 - 2) }
        };

        // Update DOM elements
        document.querySelector('.metric-card:nth-child(1) .metric-value').textContent = metrics.inventory.value.toLocaleString();
        document.querySelector('.metric-card:nth-child(2) .metric-value').textContent = metrics.shipments.value;
        document.querySelector('.metric-card:nth-child(3) .metric-value').textContent = metrics.leadTime.value + ' days';
        document.querySelector('.metric-card:nth-child(4) .metric-value').textContent = metrics.alerts.value;

        // Update change indicators
        this.updateChangeIndicator('.metric-card:nth-child(1) .metric-change', metrics.inventory.change + '%');
        this.updateChangeIndicator('.metric-card:nth-child(2) .metric-change', metrics.shipments.change + '%');
        this.updateChangeIndicator('.metric-card:nth-child(3) .metric-change', metrics.leadTime.change + '%');
        this.updateChangeIndicator('.metric-card:nth-child(4) .metric-change', (metrics.alerts.change >= 0 ? '+' : '') + metrics.alerts.change);
        
        // Update At a Glance section
        this.updateAtGlanceMetrics();
    }

    updateAtGlanceMetrics() {
        // Update performance metrics with slight variations
        const performanceMetrics = {
            onTime: Math.max(75, Math.min(95, 85 + Math.random() * 10 - 5)),
            accuracy: Math.max(85, Math.min(98, 92 + Math.random() * 6 - 3)),
            supplier: Math.max(70, Math.min(85, 78 + Math.random() * 8 - 4))
        };

        // Update progress bars
        const progressBars = document.querySelectorAll('.progress-fill');
        const statValues = document.querySelectorAll('.stat-value');
        
        if (progressBars.length >= 3 && statValues.length >= 3) {
            progressBars[0].style.width = performanceMetrics.onTime + '%';
            progressBars[1].style.width = performanceMetrics.accuracy + '%';
            progressBars[2].style.width = performanceMetrics.supplier + '%';
            
            statValues[0].textContent = Math.round(performanceMetrics.onTime) + '%';
            statValues[1].textContent = Math.round(performanceMetrics.accuracy) + '%';
            statValues[2].textContent = Math.round(performanceMetrics.supplier) + '%';
        }

        // Update operational counts with small variations
        const opCounts = document.querySelectorAll('.op-count');
        if (opCounts.length >= 4) {
            opCounts[0].textContent = '12'; // Warehouses (stable)
            opCounts[1].textContent = (245 + Math.floor(Math.random() * 10 - 5)).toString(); // Suppliers
            opCounts[2].textContent = (89 + Math.floor(Math.random() * 15 - 7)).toString(); // Routes
            opCounts[3].textContent = (1247 + Math.floor(Math.random() * 100 - 50)).toLocaleString(); // Orders
        }

        // Update financial values
        const financeValues = document.querySelectorAll('.finance-value');
        if (financeValues.length >= 3) {
            const revenue = 2.4 + (Math.random() * 0.4 - 0.2);
            const costs = 1.8 + (Math.random() * 0.2 - 0.1);
            const savings = (revenue - costs) * 1000000 * 0.1;
            
            financeValues[0].textContent = '$' + revenue.toFixed(1) + 'M';
            financeValues[1].textContent = '$' + costs.toFixed(1) + 'M';
            financeValues[2].textContent = '$' + Math.round(savings / 1000) + 'K';
        }
    }

    updateChangeIndicator(selector, value) {
        const element = document.querySelector(selector);
        if (element) {
            element.textContent = value;
            element.className = 'metric-change ' + (parseFloat(value) >= 0 ? 'positive' : 'negative');
        }
    }

    updateChartData() {
        // Update charts with new data points
        Object.keys(this.charts).forEach(chartKey => {
            const chart = this.charts[chartKey];
            if (chart && chart.data && chart.data.datasets) {
                chart.data.datasets.forEach(dataset => {
                    if (dataset.data && Array.isArray(dataset.data)) {
                        // Add some variation to the data
                        dataset.data = dataset.data.map(value => {
                            if (value !== null && typeof value === 'number') {
                                return Math.max(0, value + (Math.random() * 20 - 10));
                            }
                            return value;
                        });
                    }
                });
                chart.update('none'); // Update without animation for smoother experience
            }
        });
    }

    // Warehouse Management System
    initWarehouseSystem() {
        // Generate warehouse data
        this.warehouseData = this.generateWarehouseData();
        
        // Initialize warehouse table
        this.populateWarehouseTable();
        
        // Initialize warehouse controls
        this.initWarehouseControls();
    }

    generateWarehouseData() {
        const warehouses = [
            { id: 'WH001', name: 'NYC Central', location: 'New York' },
            { id: 'WH002', name: 'LA West Coast', location: 'Los Angeles' },
            { id: 'WH003', name: 'Chicago Midwest', location: 'Chicago' },
            { id: 'WH004', name: 'Miami Southeast', location: 'Miami' },
            { id: 'WH005', name: 'Dallas Southwest', location: 'Dallas' }
        ];

        const items = [
            { name: 'Steel Beams', category: 'Raw Materials' },
            { name: 'Circuit Boards', category: 'Electronics' },
            { name: 'Cotton Fabric', category: 'Textiles' },
            { name: 'Aluminum Sheets', category: 'Raw Materials' },
            { name: 'LED Displays', category: 'Electronics' },
            { name: 'Polyester Thread', category: 'Textiles' },
            { name: 'Copper Wire', category: 'Raw Materials' },
            { name: 'Microprocessors', category: 'Electronics' },
            { name: 'Denim Fabric', category: 'Textiles' },
            { name: 'Titanium Alloy', category: 'Raw Materials' },
            { name: 'OLED Panels', category: 'Electronics' },
            { name: 'Silk Material', category: 'Textiles' },
            { name: 'Carbon Fiber', category: 'Raw Materials' },
            { name: 'Memory Chips', category: 'Electronics' },
            { name: 'Wool Blend', category: 'Textiles' }
        ];

        const statuses = ['in-route', 'ordered', 'need-order'];
        const data = [];

        warehouses.forEach(warehouse => {
            items.forEach((item, index) => {
                const quantity = Math.floor(Math.random() * 1000) + 50;
                const maxQuantity = 1000;
                const status = statuses[Math.floor(Math.random() * statuses.length)];
                
                // Generate realistic supply dates
                const daysFromNow = Math.floor(Math.random() * 30) + 1;
                const supplyDate = new Date();
                supplyDate.setDate(supplyDate.getDate() + daysFromNow);

                data.push({
                    warehouse: warehouse,
                    itemName: item.name,
                    itemNumber: `ITM-${warehouse.id}-${String(index + 1).padStart(3, '0')}`,
                    quantity: quantity,
                    maxQuantity: maxQuantity,
                    category: item.category,
                    nextSupplyDue: supplyDate,
                    supplyStatus: status,
                    lastUpdated: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000) // Random date within last week
                });
            });
        });

        return data;
    }

    populateWarehouseTable(filteredData = null) {
        const tbody = document.getElementById('warehouseTableBody');
        if (!tbody) return;

        const data = filteredData || this.warehouseData;
        tbody.innerHTML = '';

        data.forEach((item, index) => {
            const row = document.createElement('tr');
            
            // Calculate quantity status
            const quantityPercent = (item.quantity / item.maxQuantity) * 100;
            let quantityStatus = 'high';
            if (quantityPercent < 25) quantityStatus = 'low';
            else if (quantityPercent < 60) quantityStatus = 'medium';

            // Format supply date
            const supplyDate = item.nextSupplyDue.toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                year: 'numeric'
            });

            row.innerHTML = `
                <td>
                    <div class="warehouse-info">
                        <strong>${item.warehouse.name}</strong>
                        <br><small style="color: var(--muted);">${item.warehouse.id}</small>
                    </div>
                </td>
                <td>
                    <div class="item-info">
                        <strong>${item.itemName}</strong>
                        <br><small style="color: var(--muted);">${item.category}</small>
                    </div>
                </td>
                <td>
                    <span class="item-number">${item.itemNumber}</span>
                </td>
                <td>
                    <div class="quantity-display">
                        <span class="quantity-number">${item.quantity.toLocaleString()}</span>
                        <div class="quantity-bar">
                            <div class="quantity-fill ${quantityStatus}" style="width: ${quantityPercent}%"></div>
                        </div>
                    </div>
                </td>
                <td>
                    <span class="supply-date">${supplyDate}</span>
                </td>
                <td>
                    <span class="supply-status ${item.supplyStatus}">
                        ${this.getStatusIcon(item.supplyStatus)}
                        ${this.formatStatus(item.supplyStatus)}
                    </span>
                </td>
                <td>
                    <button class="action-btn view" onclick="showItemDetails(${index})">
                        <i class="fas fa-eye"></i> View
                    </button>
                    ${item.supplyStatus === 'need-order' ? 
                        `<button class="action-btn order" onclick="createOrder(${index})">
                            <i class="fas fa-plus"></i> Order
                        </button>` : ''}
                </td>
            `;

            tbody.appendChild(row);
        });
    }

    getStatusIcon(status) {
        switch(status) {
            case 'in-route': return '<i class="fas fa-truck"></i>';
            case 'ordered': return '<i class="fas fa-clock"></i>';
            case 'need-order': return '<i class="fas fa-exclamation-triangle"></i>';
            default: return '<i class="fas fa-question"></i>';
        }
    }

    formatStatus(status) {
        return status.split('-').map(word => 
            word.charAt(0).toUpperCase() + word.slice(1)
        ).join(' ');
    }

    initWarehouseControls() {
        const warehouseSelect = document.getElementById('warehouseSelect');
        const statusFilter = document.getElementById('statusFilter');
        const searchInput = document.getElementById('searchItems');
        const searchBtn = document.querySelector('.search-btn');

        if (warehouseSelect) {
            warehouseSelect.addEventListener('change', () => this.filterWarehouseData());
        }

        if (statusFilter) {
            statusFilter.addEventListener('change', () => this.filterWarehouseData());
        }

        if (searchInput) {
            searchInput.addEventListener('input', () => this.filterWarehouseData());
        }

        if (searchBtn) {
            searchBtn.addEventListener('click', () => this.filterWarehouseData());
        }
    }

    filterWarehouseData() {
        const warehouseSelect = document.getElementById('warehouseSelect');
        const statusFilter = document.getElementById('statusFilter');
        const searchInput = document.getElementById('searchItems');

        let filteredData = this.warehouseData;

        // Filter by warehouse
        if (warehouseSelect && warehouseSelect.value !== 'all') {
            filteredData = filteredData.filter(item => 
                item.warehouse.id === warehouseSelect.value
            );
        }

        // Filter by status
        if (statusFilter && statusFilter.value !== 'all') {
            filteredData = filteredData.filter(item => 
                item.supplyStatus === statusFilter.value
            );
        }

        // Filter by search term
        if (searchInput && searchInput.value.trim()) {
            const searchTerm = searchInput.value.trim().toLowerCase();
            filteredData = filteredData.filter(item => 
                item.itemName.toLowerCase().includes(searchTerm) ||
                item.itemNumber.toLowerCase().includes(searchTerm) ||
                item.warehouse.name.toLowerCase().includes(searchTerm)
            );
        }

        this.populateWarehouseTable(filteredData);
    }

    // Update warehouse stats in real-time
    updateWarehouseStats() {
        if (!this.warehouseData) return;

        const totalItems = this.warehouseData.reduce((sum, item) => sum + item.quantity, 0);
        const lowStockItems = this.warehouseData.filter(item => 
            (item.quantity / item.maxQuantity) < 0.25
        ).length;
        const pendingOrders = this.warehouseData.filter(item => 
            item.supplyStatus === 'need-order'
        ).length;

        // Update DOM elements if they exist
        const totalElement = document.querySelector('.warehouse-stat-card:nth-child(2) h3');
        if (totalElement) {
            totalElement.textContent = totalItems.toLocaleString();
        }

        const lowStockElement = document.querySelector('.warehouse-stat-card:nth-child(3) h3');
        if (lowStockElement) {
            lowStockElement.textContent = lowStockItems;
        }

        const pendingElement = document.querySelector('.warehouse-stat-card:nth-child(4) h3');
        if (pendingElement) {
            pendingElement.textContent = pendingOrders;
        }
    }

    // Utility methods for data simulation
    generateSupplyChainNews() {
        const newsItems = [
            {
                title: "Global Shipping Rates See 12% Increase",
                content: "Rising fuel costs and port congestion contribute to increased shipping rates across major trade routes.",
                time: "2 hours ago"
            },
            {
                title: "New Trade Agreement Signed",
                content: "The new bilateral trade agreement is expected to reduce import duties by 8% starting next quarter.",
                time: "5 hours ago"
            },
            {
                title: "AI-Powered Logistics Platform Launches",
                content: "Revolutionary AI platform promises to optimize supply chain routes and reduce delivery times by 25%.",
                time: "1 day ago"
            },
            {
                title: "Semiconductor Shortage Update",
                content: "Industry experts predict semiconductor supply will stabilize in the next 6-8 months.",
                time: "2 days ago"
            }
        ];
        return newsItems;
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.dashboard = new SupplyChainDashboard();
});

// Global functions for warehouse management
function showItemDetails(index) {
    if (!window.dashboard || !window.dashboard.warehouseData) return;
    
    const item = window.dashboard.warehouseData[index];
    const modal = document.getElementById('warehouseModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalBody = document.getElementById('modalBody');
    
    if (!modal || !item) return;
    
    modalTitle.textContent = `${item.itemName} - ${item.itemNumber}`;
    
    const quantityPercent = (item.quantity / item.maxQuantity) * 100;
    let stockLevel = 'High';
    let stockColor = '#10b981';
    if (quantityPercent < 25) {
        stockLevel = 'Critical Low';
        stockColor = '#ef4444';
    } else if (quantityPercent < 60) {
        stockLevel = 'Low';
        stockColor = '#f59e0b';
    }
    
    modalBody.innerHTML = `
        <div class="item-detail-grid">
            <div class="detail-section">
                <h4>Item Information</h4>
                <div class="detail-row">
                    <span class="detail-label">Item Name:</span>
                    <span class="detail-value">${item.itemName}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Item Number:</span>
                    <span class="detail-value">${item.itemNumber}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Category:</span>
                    <span class="detail-value">${item.category}</span>
                </div>
            </div>
            
            <div class="detail-section">
                <h4>Warehouse Location</h4>
                <div class="detail-row">
                    <span class="detail-label">Warehouse:</span>
                    <span class="detail-value">${item.warehouse.name}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Location:</span>
                    <span class="detail-value">${item.warehouse.location}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Warehouse ID:</span>
                    <span class="detail-value">${item.warehouse.id}</span>
                </div>
            </div>
            
            <div class="detail-section">
                <h4>Stock Information</h4>
                <div class="detail-row">
                    <span class="detail-label">Current Quantity:</span>
                    <span class="detail-value">${item.quantity.toLocaleString()} units</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Stock Level:</span>
                    <span class="detail-value" style="color: ${stockColor}; font-weight: 600;">${stockLevel}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Last Updated:</span>
                    <span class="detail-value">${item.lastUpdated.toLocaleDateString()}</span>
                </div>
            </div>
            
            <div class="detail-section">
                <h4>Supply Information</h4>
                <div class="detail-row">
                    <span class="detail-label">Next Supply Due:</span>
                    <span class="detail-value">${item.nextSupplyDue.toLocaleDateString()}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Supply Status:</span>
                    <span class="detail-value">
                        <span class="supply-status ${item.supplyStatus}">
                            ${window.dashboard.getStatusIcon(item.supplyStatus)}
                            ${window.dashboard.formatStatus(item.supplyStatus)}
                        </span>
                    </span>
                </div>
            </div>
        </div>
    `;
    
    modal.style.display = 'flex';
}

function closeWarehouseModal() {
    const modal = document.getElementById('warehouseModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

function createOrder(index) {
    if (!window.dashboard || !window.dashboard.warehouseData) return;
    
    const item = window.dashboard.warehouseData[index];
    if (confirm(`Create new supply order for ${item.itemName} at ${item.warehouse.name}?`)) {
        // Update the status to 'ordered'
        item.supplyStatus = 'ordered';
        
        // Set new supply date (random 7-21 days from now)
        const daysFromNow = Math.floor(Math.random() * 14) + 7;
        item.nextSupplyDue = new Date();
        item.nextSupplyDue.setDate(item.nextSupplyDue.getDate() + daysFromNow);
        
        // Refresh the table to show updated status
        window.dashboard.populateWarehouseTable();
        window.dashboard.updateWarehouseStats();
        
        alert(`Order created successfully! Expected delivery: ${item.nextSupplyDue.toLocaleDateString()}`);
    }
}

function updateSupplyOrder() {
    alert('Supply order update functionality would integrate with your ERP system.');
    closeWarehouseModal();
}

// Close modal when clicking outside
window.addEventListener('click', (e) => {
    const modal = document.getElementById('warehouseModal');
    if (e.target === modal) {
        closeWarehouseModal();
    }
});

// Add CSS for modal details
const modalStyle = document.createElement('style');
modalStyle.textContent = `
    .item-detail-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 2rem;
    }
    
    .detail-section {
        background: rgba(255, 255, 255, 0.03);
        padding: 1.5rem;
        border-radius: 8px;
        border: 1px solid var(--border);
    }
    
    .detail-section h4 {
        color: var(--accent);
        margin-bottom: 1rem;
        padding-bottom: 0.5rem;
        border-bottom: 1px solid var(--border);
    }
    
    .detail-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.75rem;
        padding: 0.5rem 0;
    }
    
    .detail-label {
        color: var(--muted);
        font-size: 0.875rem;
    }
    
    .detail-value {
        color: var(--text);
        font-weight: 500;
    }
    
    @media (max-width: 768px) {
        .item-detail-grid {
            grid-template-columns: 1fr;
            gap: 1rem;
        }
    }
`;
document.head.appendChild(modalStyle);

// Handle window resize for chart responsiveness
window.addEventListener('resize', () => {
    if (window.dashboard && window.dashboard.charts) {
        Object.keys(window.dashboard.charts).forEach(chartKey => {
            const chart = window.dashboard.charts[chartKey];
            if (chart) {
                chart.resize();
            }
        });
    }
});
